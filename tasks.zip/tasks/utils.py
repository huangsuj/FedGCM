import numpy as np
import torch
from sklearn.metrics import roc_auc_score
import torch.nn.functional as F
def train(args, model, train_idx, labels, device, optimizer, loss_fn, adj_high, adj_low, data):
    model.train()
    optimizer.zero_grad()
    if args.gmodel_name == 'ACM':
        train_output, _ = model.forward(data, adj_low, adj_high)
        train_output = train_output[train_idx]
    else:
        train_output = model.model_forward(train_idx, device)
    loss_train = loss_fn(train_output, labels[train_idx])
    acc_train = accuracy(train_output, labels[train_idx])
    loss_train.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
    optimizer.step()
    # print("#############Loss train", loss_train)
    return loss_train.item(), acc_train


def evaluate(args, model, val_idx, test_idx, labels, device, adj_high, adj_low, data):
    model.eval()
    if args.gmodel_name == 'ACM':
        output, _ = model.forward(data, adj_low, adj_high)
    else:
        output = model.model_forward(range(len(val_idx)), device)
    acc_val = accuracy(output[val_idx], labels[val_idx])
    acc_test = accuracy(output[test_idx], labels[test_idx])
    return acc_val, acc_test

    
def accuracy(output, labels):
    pred = output.max(1)[1].type_as(labels)
    correct = pred.eq(labels).double()
    correct = correct.sum()
    return (correct / len(labels)).item()

def normalize_tensor(mx, eqvar=None):
    """
    Row-normalize sparse matrix
    """
    rowsum = torch.sum(mx, 1)
    if eqvar:
        r_inv = torch.pow(rowsum, -1 / eqvar).flatten()
        r_inv[torch.isinf(r_inv)] = 0.0
        r_mat_inv = torch.diag(r_inv)
        mx = torch.mm(r_mat_inv, mx)
        return mx

    else:
        r_inv = torch.pow(rowsum, -1).flatten()
        r_inv[torch.isinf(r_inv)] = 0.0
        r_mat_inv = torch.diag(r_inv)
        mx = torch.mm(r_mat_inv, mx)
        return mx

def train_prep(logger, adj_low_unnormalized, device, labels, args):
    np.random.seed(42)
    torch.manual_seed(42)

    nnodes = labels.shape[0]

    adj_low = normalize_tensor(torch.eye(nnodes) + adj_low_unnormalized.to_dense())
    adj_high = (torch.eye(nnodes) - adj_low).to(device).to_sparse()
    adj_low = adj_low.to(device)
    return adj_high.to(device),adj_low.to(device)

