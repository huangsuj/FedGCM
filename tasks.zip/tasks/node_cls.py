import time
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.utils.data import DataLoader
import torch.nn.functional as F
from tasks.base_task import BaseTask
from tasks.utils import train, evaluate, accuracy
from tasks.utils import train_prep
from tasks.logger import ACMPythorchLogger
logger = ACMPythorchLogger()
import numpy as np
import scipy.sparse as sp
from sklearn.metrics import roc_auc_score
def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    sparse_mx = sparse_mx.tocoo().astype(np.float32)

    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))

    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

class SGLNodeClassification(BaseTask):
    def __init__(self, args, dataset, model, lr, weight_decay, epochs, device, show_epoch_info = 20, loss_fn=nn.CrossEntropyLoss()):
        super(SGLNodeClassification, self).__init__()
        self.dataset = dataset
        self.args = args
        self.labels = self.dataset.y
        self.model = model
        self.optimizer = Adam(model.parameters(), lr=lr,
                                weight_decay=weight_decay)
        self.epochs = epochs
        self.show_epoch_info = show_epoch_info
        self.loss_fn = loss_fn
        self.device = device

    def execute(self):
        self.model = self.model.to(self.device)
        self.labels = self.labels.to(self.device)
        best_val = 0.
        best_test = 0.
        for epoch in range(self.epochs):
            t = time.time()
            loss_train, acc_train = train(self.args, self.model, self.dataset.train_idx, self.labels, self.device,
                                            self.optimizer, self.loss_fn, self.dataset.adj_high, self.dataset.adj_low, self.dataset)
            acc_val, acc_test = evaluate(self.args, self.model, self.dataset.val_idx, self.dataset.test_idx,
                                            self.labels, self.device, self.dataset.adj_high, self.dataset.adj_low, self.dataset)
            if acc_val > best_val:
                best_val = acc_val
                best_test = acc_test
        acc_val, acc_test = self.postprocess()
        if acc_val > best_val:
            best_val = acc_val
            best_test = acc_test
        return best_val, best_test, self.model
    
    def postprocess(self):
        self.model.eval()
        if self.args.gmodel_name == 'ACM':
            embedding, outputs = self.model.forward(self.dataset, self.dataset.adj_low, self.dataset.adj_high)
            final_output = embedding
        else:
            outputs = self.model.model_forward(
                range(self.dataset.num_nodes), self.device).to("cpu")
            final_output = self.model.postprocess(self.dataset.adj, outputs)
        acc_val = accuracy(
            final_output[self.dataset.val_idx], self.labels[self.dataset.val_idx])
        acc_test = accuracy(
            final_output[self.dataset.test_idx], self.labels[self.dataset.test_idx])
        return acc_val, acc_test


class SGLEvaluateModelClients(BaseTask):
    def __init__(self, args, dataset, model, device):
        super(SGLEvaluateModelClients, self).__init__()
        self.dataset = dataset
        self.labels = self.dataset.y
        self.model = model
        self.args = args
        self.device = device
        self.adj_low_unnormalized = sparse_mx_to_torch_sparse_tensor(self.dataset.adj)

    def execute(self):
        self.model = self.model.to(self.device)
        self.labels = self.labels.to(self.device)
        acc_val, acc_test = self.postprocess()
        return acc_val, acc_test

    def postprocess(self):
        self.model.eval()
        if self.args.gmodel_name == 'ACM':
            embedding, outputs = self.model.forward(self.dataset, self.dataset.adj_low, self.dataset.adj_high)
            final_output = embedding.to("cpu")
        else:
            outputs = self.model.model_forward(
                range(self.dataset.num_nodes), self.device).to("cpu")
            final_output = self.model.postprocess(self.dataset.adj, outputs)
        acc_val = accuracy(
        final_output[self.dataset.val_idx], self.labels[self.dataset.val_idx])
        acc_test = accuracy(
            final_output[self.dataset.test_idx], self.labels[self.dataset.test_idx])
        return acc_val, acc_test

