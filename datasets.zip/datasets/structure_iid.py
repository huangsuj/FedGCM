import torch
from config import args
from datasets.louvain.community import community_louvain
from sklearn.cluster import spectral_clustering
import collections
import networkx as nx
import numpy as np


def structure_iid_louvain(graph, num_clients):
    local_nodes = [[] for _ in range(num_clients)]

    partition = community_louvain.best_partition(graph)
    groups = collections.defaultdict(list)
    for ni, gi in partition.items():
        groups[gi].append(ni)
    groups = {k: groups[k] for k in list(range(len(groups)))}

    while len(groups) < num_clients:
        groups_lens = [len(groups[k]) for k in range(len(groups))]
        max_gi = np.argmax(groups_lens)

        min_glen = min(groups_lens)
        max_glen = max(groups_lens)

        if max_glen < 2 * min_glen:
            min_glen = max_glen // 2

        nodes_in_gi = groups[max_gi]
        new_group_id = len(groups)

        groups[new_group_id] = nodes_in_gi[:min_glen]
        groups[max_gi] = nodes_in_gi[min_glen:]

    groups_lens = [len(groups[k]) for k in range(len(groups))]

    group_ids = np.argsort(groups_lens)

    for gi in group_ids:
        current_client_loads = [len(li) for li in local_nodes]
        cid = np.argmin(current_client_loads)
        local_nodes[cid].extend(groups[gi])

    node_dict = {i: local_nodes[i] for i in range(num_clients)}

    return node_dict

def structure_iid_sc(num_nodes,F,num_clients):
    S = torch.sigmoid(torch.mm(F, F.T))
    S = S.cpu().detach().numpy()
    clustering_lbls = spectral_clustering(affinity=S, n_clusters=num_clients)
    clustering_lbls = clustering_lbls.tolist()
    node_dict = {client_id: [] for client_id in range(num_clients)}
    for node_idx in range(num_nodes):
        node_dict[clustering_lbls[node_idx]].append(node_idx)
    return node_dict