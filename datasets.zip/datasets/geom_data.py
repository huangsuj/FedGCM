import torch
import numpy as np
import os
import os.path as osp
import scipy.sparse as sp
from torch import Tensor
from scipy.sparse import csr_matrix
from torch_geometric.data import Data
from torch_geometric.datasets import WikipediaNetwork

def load_geom_data(root, name):
    root = './datasets'
    data = WikipediaNetwork(root=f'{root}', name=name)[0]
    data.train_mask = None
    data.val_mask = None
    data.test_mask = None
    data.input_dim = data.num_features
    data.output_dim = data.y.max().item() + 1
    data.adj = sp.coo_matrix((torch.ones([len(data.edge_index[0])]), (data.edge_index[0], data.edge_index[1])), shape=(data.num_nodes, data.num_nodes))
    data.row, data.col, data.edge_weight = data.adj.row, data.adj.col, data.adj.data
    if isinstance(data.row, Tensor) or isinstance(data.col, Tensor):
        data.adj = csr_matrix((data.edge_weight.numpy(), (data.row.numpy(), data.col.numpy())),
                                        shape=(data.num_nodes, data.num_nodes))
    else:
        data.adj = csr_matrix((data.edge_weight, (data.row, data. col)), shape=(data.num_nodes, data.num_nodes))
    # torch.save(data, processed_file)
    return data

def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    rowsum = (rowsum==0)*1+rowsum
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx