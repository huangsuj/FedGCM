import torch
import random
import numpy as np
import scipy.sparse as sp
from torch import Tensor
from scipy.sparse import csr_matrix
from datasets.utils import idx_to_mask
from torch_geometric.data import Data
from torch_geometric.utils.convert import to_networkx
from utils import set_seed
from tasks.utils import train_prep
from tasks.logger import ACMPythorchLogger
logger = ACMPythorchLogger()

def data_partitioning(args, device, G, sampling, num_clients,
    ratio_train, ratio_val, ratio_test):
    set_seed(42)
    num_nodes = G.num_nodes
    graph_nx = to_networkx(G, to_undirected=True)
    if sampling == 'Metis':
        import pymetis as metis
        print("Conducting metis graph partition...")
        node_dict = {}
        n_cuts, membership = metis.part_graph(num_clients, graph_nx)
        for client_id in range(num_clients):
            client_indices = np.where(np.array(membership) == client_id)[0]
            client_indices = list(client_indices)
            node_dict[client_id] = client_indices
    elif sampling == 'Louvain':
        from datasets.structure_iid import structure_iid_louvain
        graph_nx_louvain = to_networkx(G, to_undirected=True)
        node_dict = structure_iid_louvain(graph=graph_nx_louvain, num_clients=num_clients)

    subgraph_list = construct_subgraph_dict_from_node_dict(
        args,
        device,
        G=G,
        num_clients=num_clients,
        node_dict=node_dict,  
        graph_nx=graph_nx, 
        ratio_train=ratio_train,
        ratio_val=ratio_val,
        ratio_test=ratio_test,
    )
    return subgraph_list


def calculate_shigh(data, sampling_rate=0.2):
    features = data.x
    num_nodes, num_features = features.shape
    if isinstance(features, torch.Tensor):
        features = features.cpu().numpy()
    if isinstance(data.edge_index, torch.Tensor):
        edge_index = data.edge_index.cpu().numpy()
    else:
        edge_index = data.edge_index

    data_val = np.ones(edge_index.shape[1])
    adj_matrix = sp.coo_matrix((data_val, (edge_index[0], edge_index[1])), shape=(num_nodes, num_nodes))
    degrees = np.array(adj_matrix.sum(1)).flatten()
    degree_matrix = sp.diags(degrees)
    laplacian_matrix = degree_matrix - adj_matrix
    sampled_indices = np.random.choice(num_features, size=int(sampling_rate * num_features), replace=False)
    S_high_values = []

    for idx in sampled_indices:
        x_k = features[:, idx]
        numerator = x_k.T @ (laplacian_matrix @ x_k)
        denominator = x_k.T @ x_k
        if denominator != 0:
            S_high = numerator / denominator
            if not np.isnan(S_high):
                S_high_values.append(S_high)

    if S_high_values:
        mean_shigh = np.mean(S_high_values)
    else:
        mean_shigh = 0.0

    return mean_shigh

def construct_subgraph_dict_from_node_dict(args, device, num_clients, node_dict, G, graph_nx,
    ratio_train, ratio_val, ratio_test):
    subgraph_list = []
    for client_id in range(num_clients):
        num_local_nodes = len(node_dict[client_id])
        local_node_idx = [idx for idx in range(num_local_nodes)]
        if args.data_name == 'penn94':
            valid_local_indices = []
            client_global_nodes = node_dict[client_id]
            for local_idx, global_idx in enumerate(client_global_nodes):
                if G.y[global_idx].item() != -1:
                    valid_local_indices.append(local_idx)
            random.shuffle(valid_local_indices)
            num_valid = len(valid_local_indices)
            train_size = int(num_valid * ratio_train)
            val_size = int(num_valid * ratio_val)
            train_idx = valid_local_indices[: train_size]
            val_idx = valid_local_indices[train_size: train_size + val_size]
            test_idx = valid_local_indices[train_size + val_size:]
        else:
            random.shuffle(local_node_idx)
            train_size = int(num_local_nodes * ratio_train)
            val_size = int(num_local_nodes * ratio_val)
            test_size = int(num_local_nodes * ratio_test)
            train_idx = local_node_idx[: train_size]
            val_idx = local_node_idx[train_size: train_size + val_size]
            test_idx = local_node_idx[train_size + val_size:]
        local_train_idx = idx_to_mask(train_idx, size=num_local_nodes)
        local_val_idx = idx_to_mask(val_idx, size=num_local_nodes)
        local_test_idx = idx_to_mask(test_idx, size=num_local_nodes)
        map_train_idx = []
        map_val_idx = []
        map_test_idx = []
        map_train_idx += [node_dict[client_id][idx] for idx in train_idx]
        map_val_idx   += [node_dict[client_id][idx] for idx in val_idx  ]
        map_test_idx  += [node_dict[client_id][idx] for idx in test_idx ]
        global_train_idx = idx_to_mask(map_train_idx, size=G.y.size(0))
        global_val_idx = idx_to_mask(map_val_idx, size=G.y.size(0))
        global_test_idx = idx_to_mask(map_test_idx, size=G.y.size(0))
        node_idx_map = {}
        edge_idx = []
        for idx in range(num_local_nodes):
            node_idx_map[node_dict[client_id][idx]] = idx
        edge_idx += [(node_idx_map[x[0]], node_idx_map[x[1]]) for x in graph_nx.subgraph(node_dict[client_id]).edges]
        edge_idx += [(node_idx_map[x[1]], node_idx_map[x[0]]) for x in graph_nx.subgraph(node_dict[client_id]).edges]
        edge_idx_tensor = torch.tensor(edge_idx, dtype=torch.long).T
        from torch_geometric.utils import add_self_loops
        edge_idx_tensor, _ = add_self_loops(edge_idx_tensor, num_nodes=G.x[node_dict[client_id]].size(0))
        subgraph = Data(x=G.x[node_dict[client_id]],
                        y=G.y[node_dict[client_id]],

                        edge_index=edge_idx_tensor)
        s_value = calculate_shigh(subgraph, sampling_rate=0.2)
        subgraph.ratio = s_value

        subgraph.adj = sp.coo_matrix((torch.ones([len(edge_idx_tensor[0])]), (edge_idx_tensor[0], edge_idx_tensor[1])),
                                     shape=(num_local_nodes, num_local_nodes))
        subgraph.row, subgraph.col, subgraph.edge_weight = subgraph.adj.row, subgraph.adj.col, subgraph.adj.data
        if isinstance(subgraph.adj.row, Tensor) or isinstance(subgraph.adj.col, Tensor):
            subgraph.adj = csr_matrix((subgraph.edge_weight.numpy(), (subgraph.row.numpy(), subgraph.col.numpy())),
                                            shape=(subgraph.num_nodes, subgraph.num_nodes))
        else:
            subgraph.adj = csr_matrix((subgraph.edge_weight, (subgraph.row, subgraph.col)), shape=(subgraph.num_nodes, subgraph.num_nodes))

        adj_low_unnormalized = sparse_mx_to_torch_sparse_tensor(subgraph.adj)

        subgraph.adj_high,subgraph.adj_low = train_prep(logger, adj_low_unnormalized, device, subgraph.y, args)
        subgraph.train_idx = local_train_idx
        subgraph.val_idx = local_val_idx
        subgraph.test_idx = local_test_idx
        subgraph.global_train_idx = global_train_idx
        subgraph.global_val_idx = global_val_idx
        subgraph.global_test_idx = global_test_idx
        subgraph_list.append(subgraph)
    return subgraph_list

def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)

    return torch.sparse.FloatTensor(indices, values, shape)