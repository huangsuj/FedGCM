import time
import numpy as np
import random
import torch
import os.path as osp
from config import args
from collections import OrderedDict
from models.ACM import ACM
from tasks.node_cls import SGLNodeClassification, SGLEvaluateModelClients
from utils import project_conflicting, flatten_grads_vector, unflatten_vector_to_dict
import copy

class ServerManager():
    def __init__(self, args, model_name, datasets, num_clients, device, num_rounds, client_sample_ratio):
        self.hidden_dim = args.hidden_dim
        self.nlayers = 3
        self.model_name = model_name
        self.datasets = datasets
        self.input_dim = datasets.input_dim
        self.output_dim = datasets.output_dim
        self.global_data = datasets.global_data
        self.subgraphs = datasets.subgraphs
        self.num_clients = num_clients
        self.device = device
        self.client_sample_ratio = client_sample_ratio
        self.state_dict_records = []
        self.num_rounds = num_rounds
        self.args= args
        self.init_model()

    def init_model(self):
        self.model = ACM(self.input_dim, self.hidden_dim, self.output_dim, self.nlayers, dropout=args.drop, model_type='acmgcnp', variant=False, init_layers_X=1)

    def set_state_dict(self, state_dict):
        self.model.load_state_dict(state_dict=state_dict)

    def model_aggregation(self, server_input, mixing_coefficients):
        aggregated_model = OrderedDict()

        server_input = [a.state_dict() for a in server_input]
        for it, state_dict in enumerate(server_input):
            for key in state_dict.keys():
                if it == 0:
                    aggregated_model[key] = mixing_coefficients[it] * state_dict[key]
                else:
                    aggregated_model[key] += mixing_coefficients[it] * state_dict[key]
        return aggregated_model

    def manual_edge_homophily(self, edge_index, y):
        src, dst = edge_index[0], edge_index[1]
        same_label = (y[src] == y[dst]).sum().item()
        total_edges = edge_index.size(1)
        return same_label / total_edges if total_edges > 0 else 0

    def collaborative_training_model(self, table_rows, clients, data_name, num_clients, sampling, model_name, normalize_trains=args.normalize_train, lr=args.lr, weight_decay=args.weight_decay, epochs=args.num_epochs):
        print("| ★  Start Training Federated GNN Model...")
        normalize_record = {"val_acc": [], "test_acc": []}
        total_client_nodes = sum([g.num_nodes for g in self.datasets.subgraphs])  ###自己加：所有客户端节点数之和
        K = self.args.K
        import numpy as np
        all_runs_test_accs = np.zeros((normalize_trains, self.num_rounds))
        for num in range(normalize_trains):

            clients_test_acc = []
            clients_val_acc = []
            self.init_model()
            for client_id in range(self.num_clients):
                clients_test_acc.append(0)
                clients_val_acc.append(0)
                c = clients[client_id]
                c.clear_record()
                c.init_model()
                c.model.preprocess(c.local_subgraph.adj, c.local_subgraph.x)

            group_params_list = [copy.deepcopy(self.model.state_dict()) for _ in range(K)]
            all_client_idx = list(range(self.num_clients))
            random.shuffle(all_client_idx)
            sample_num = int(len(all_client_idx) * self.client_sample_ratio)
            sample_idx = sorted(all_client_idx[:sample_num])
            current_ratios = [clients[i].local_subgraph.ratio for i in sample_idx]
            min_h, max_h = min(current_ratios), max(current_ratios)
            span = max_h - min_h + 1e-9

            round_global_record = {"global_val_acc": 0, "global_test_acc": 0}

            for round_id in range(self.num_rounds):
                import math
                current_lr = lr * 0.5 * (1 + math.cos(math.pi * round_id / self.num_rounds))
                uploaded_info = []
                for client_id in sample_idx:
                    h = clients[client_id].local_subgraph.ratio
                    group_id = int((h - min_h) / span * K)
                    group_id = min(group_id, K - 1)

                    clients[client_id].model.load_state_dict(group_params_list[group_id])
                    _, _, local_model = SGLNodeClassification(args, dataset=clients[client_id].local_subgraph,
                                                              model=clients[client_id].model, lr=current_lr,
                                                              weight_decay=weight_decay, epochs=epochs,
                                                              device=self.device).execute()

                    with torch.no_grad():
                        global_params = group_params_list[group_id]
                        local_params = local_model.state_dict()
                        client_gradient = {}

                        for key in global_params:
                            if global_params[key].dtype in [torch.float32, torch.float64]:
                                client_gradient[key] = (global_params[key].to(self.device) - local_params[key].to(self.device)) / current_lr

                        uploaded_info.append({
                            "client_id": client_id,
                            "client_homo": h,
                            "gradient": client_gradient,
                            "num_nodes": clients[client_id].num_nodes,
                            "group_id": group_id
                        })

                groups = [[] for _ in range(K)]
                for item in uploaded_info:
                    groups[item["group_id"]].append(item)

                group_mean_grads_flat = []
                template_grad_dict = None

                for group_items in groups:
                    if len(group_items) == 0:
                        group_mean_grads_flat.append(None)
                        continue

                    if template_grad_dict is None:
                        template_grad_dict = group_items[0]["gradient"]
                    valid_keys = [k for k in template_grad_dict if
                                  template_grad_dict[k].dtype in [torch.float32, torch.float64]]

                    sum_grad = {}
                    total_nodes = sum([item["num_nodes"] for item in group_items])
                    weights = torch.tensor([item["num_nodes"] / total_nodes for item in group_items],
                                           device=self.device)
                    with torch.no_grad():
                        for k in valid_keys:
                            stacked_grads = torch.stack([item["gradient"][k].to(self.device) for item in group_items])
                            view_shape = [-1] + [1] * (stacked_grads.dim() - 1)
                            sum_grad[k] = (stacked_grads * weights.view(*view_shape)).sum(dim=0)

                    group_mean_grads_flat.append(flatten_grads_vector(sum_grad))

                ###residual projection
                corrected_grads_flat = project_conflicting(self.args, group_mean_grads_flat)

                if template_grad_dict is not None:
                    for i in range(K):
                        g_flat = corrected_grads_flat[i]
                        if g_flat is not None:
                            grad_dict = unflatten_vector_to_dict(g_flat, template_grad_dict)
                            real_grad_norm = 0.0
                            with torch.no_grad():
                                for key in group_params_list[i]:
                                    if key in grad_dict and group_params_list[i][key].dtype in [torch.float32,
                                                                                                torch.float64]:
                                        grad_tensor = grad_dict[key].to(self.device)
                                        # In-place update: parameter -= lr * grad
                                        group_params_list[i][key] = group_params_list[i][key].to(self.device)
                                        group_params_list[i][key].sub_(grad_tensor * current_lr)

                                        real_grad_norm += grad_tensor.norm(2).item() ** 2

                global_val_acc = 0
                global_test_acc = 0
                with torch.no_grad():
                    for client_id in range(self.num_clients):
                        self.model.pre_msg_learnable = clients[client_id].model.pre_msg_learnable
                        self.model.processed_feature = clients[client_id].model.processed_feature
                        self.model.adj = clients[client_id].model.adj
                        h = clients[client_id].local_subgraph.ratio
                        gid = int((h - min_h) / span * K)
                        gid = min(gid, K - 1)
                        self.model.load_state_dict(group_params_list[gid])
                        val_acc, test_acc = SGLEvaluateModelClients(args, dataset = clients[client_id].local_subgraph,
                        model = self.model,
                        device = self.device).execute()
                        if val_acc > clients_val_acc[client_id]:
                            clients_val_acc[client_id] = val_acc
                            clients_test_acc[client_id] = test_acc
                        global_val_acc += (val_acc * clients[client_id].local_subgraph.num_nodes / total_client_nodes)
                        global_test_acc += (test_acc * clients[client_id].local_subgraph.num_nodes / total_client_nodes)
                    if global_val_acc > round_global_record["global_val_acc"]:
                        round_global_record["global_val_acc"] = global_val_acc
                        round_global_record["global_test_acc"] = global_test_acc
                    all_runs_test_accs[num, round_id] = global_test_acc
                print(f"| Test Accuracy : {round_global_record['global_test_acc']:.4f}")
            print("-" * 30)
            normalize_record["val_acc"].append(round_global_record["global_val_acc"])
            normalize_record["test_acc"].append(round_global_record["global_test_acc"])
            print(f"| Test Accuracy : {round_global_record['global_test_acc']:.4f}")

        val_mean = np.mean(normalize_record["val_acc"])
        val_std = np.std(normalize_record["val_acc"])

        test_mean = np.mean(normalize_record["test_acc"])
        test_std = np.std(normalize_record["test_acc"])

        print("\n" + "=" * 40)
        print(f"| ★ Step 1 Global Training Summary ({normalize_trains} runs)")
        print("|" + "-" * 38)
        print(f"| Validation Accuracy : {val_mean:.4f} ± {val_std:.4f}")
        print(f"| Test Accuracy       : {test_mean:.4f} ± {test_std:.4f}")
        print("=" * 40 + "\n")



